# Critical Thinking Answers (draft: put these in your own words before submitting)

**Q1: Positioning context.**
If the parent `<div>` lost `position: relative`, the spans would no longer have a positioned ancestor. The browser finds an absolutely positioned element's anchor by walking up the tree until it reaches the nearest ancestor whose `position` is anything other than `static`. With none, it falls back to the initial containing block (the viewport-sized area at the top of the page). `top: 118px; left: 152px` would then be measured from the page's top-left corner, so "I ♥ NY" would land in the upper-left of the browser window instead of on the shirt.

**Q2: Layering logic.**
`z-index` only applies to elements that are positioned (relative, absolute, fixed, sticky) or are flex/grid items. A `static` element ignores it. In this assignment the `img` is `position: relative`, so it takes part in the stacking order. If `.first`, `.heart` and `.last` were left `static` (or `z-index` was set but `position: absolute` was forgotten), their `z-index: 2` would be ignored and they would be painted in normal flow. Positioned elements paint above non-positioned ones, so the relatively positioned shirt would cover the text and "I ♥ NY" would vanish behind it.

**Q3: Animation performance.**
Animating `top`/`left` changes layout, so the browser must recalculate geometry (reflow) and repaint on every frame, and neighbouring elements may be pushed around. `transform: translate()` doesn't affect layout: the element is promoted to its own compositor layer and the GPU just moves that layer, which is cheap and can hit 60fps. With many moving elements, `top`/`left` would cause repeated reflows and repaints, giving visible jank and dropped frames, and animation happens at whole-pixel positions so movement can look choppy. Transforms also allow sub-pixel smoothness.

**Q4: Design transfer.**
For a hoodie, the *approach* stays the same: a `position: relative` container, `position: absolute` spans anchored to it, and `z-index` higher than the image. What changes are the numbers tied to the image: `top`/`left` offsets, font sizes (a hoodie's chest area is different), the image width/height, and possibly the z-index values if the hoodie image has extra layers such as a pocket. The lesson is to keep the structure and layering rules fixed but treat the coordinates and sizes as flexible values, ideally grouped in one place or defined as CSS variables so they can be re-tuned for each garment.
